<?php
defined('_JEXEC') or die();

if(!defined('DS'))
{
    define('DS',DIRECTORY_SEPARATOR);
}

jimport('sncore.include');

class plgCmpaymentSn_cmgroupbuying extends JPlugin
{
    private $type = 'hosted';
    private $paymentId = 'sn_cmgroupbuying';
    private $paymentName = 'پرداخت آنلاین';

	function __construct(&$subject,$config)
	{
	    SNGlobal::loadLanguage('plg_cmpayment_sn_cmgroupbuying',JPATH_ADMINISTRATOR);

		parent::__construct($subject,$config);
	}

    public function onCMPaymentGetIdentity()
    {
        $name = $this->params->get('name','');
        $lockTime = $this->params->get('lock_time',10);

        if(!preg_match('|^[1-9][0-9]*$|',$lockTime))
        {
            $lockTime = 10;
        }

        if(empty($name))
        {
            $name = JText::_($this->paymentName);
        }

        $extensionID = SNGlobal::selectByQuery("SELECT `extension_id` FROM `#__extensions` WHERE `element`='".SNGlobal::escape($this->paymentId)."' AND `folder`='cmpayment'",2);
        $extensionID = !empty($extensionID['extension_id']) ? $extensionID['extension_id'] : 0;

        $payment = array(
            'extension_id'	=> $extensionID,
            'id'			=> $this->paymentId,
            'name'			=> $name,
            'lock_time'		=> $lockTime,
            'type'			=> $this->type
        );

        return $payment;
    }

    public function onCMPaymentNew($cart, $order)
    {
        $app = JFactory::getApplication();

        $paymentId = $cart['payment_method']['id'];
        if($paymentId != $this->paymentId)
        {
            return false;
        }

        $buyerInfo = !empty($order['buyer_info']) ? SNGlobal::jsonDecode($order['buyer_info']) : array();

        $email = !empty($buyerInfo['email']) ? $buyerInfo['email'] : '';
        $phone = !empty($buyerInfo['phone']) ? $buyerInfo['phone'] : '';
        $orderId = $order['id'];
        $amount = $cart['total_value'];
        $backUrl = JURI::root() . 'index.php?option=com_cmgroupbuying&controller=order&task=notify&gateway='.$this->paymentId.'&order_id='.$orderId;
        $cancelUrl = JURI::root() . 'index.php?option=com_cmgroupbuying&view=cart';

        $pin = $this->params->get('sn_pin','');
        $currency = $this->params->get('sn_currency','');
        $sendPayerInfo = $this->params->get('sn_send_payer_info','');

        $amount = SNApi::modifyPrice($amount,$currency);

        $data = array(
            'pin'=> $pin,
            'price'=> $amount,
            'callback'=> $backUrl,
            'order_id'=> $orderId,
            'email' => $email,
            'mobile'=> $phone,
        );

        list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'cmgroupbuying');

        if($status == true)
        {
            $data['bank_callback_details'] = $resultData['bank_callback_details'];
            $data['au'] = $resultData['au'];

            SNApi::clearData();
            SNApi::setData($data);

            echo SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],100);
            echo '<h5 class="cm-connect-to-bank">'.JText::_('SN_CONNECTING_TO_PORTAL').'</h5>';
            return;
        }

        $msg = $msg;
        $app->redirect($cancelUrl,'<h5>'.$msg.'</h5>','error');
    }

    public function onCMPaymentValidate()
    {
        $app = JFactory::getApplication();

        $paymentId = SNGlobal::getVar('gateway');

        if(!class_exists('CMGroupBuyingControllerOrder'))
        {
            include_once JPATH_ROOT .DS. 'components'.DS.'com_cmgroupbuying'.DS.'controllers'.DS.'order.php';
        }

        if($paymentId != $this->paymentId)
        {
            return false;
        }

        $orderId = SNGlobal::getVar('order_id',0,'int');
        $au = SNGlobal::getVar('au','');
        $sessionData = SNApi::getData();
        $url = JRoute::_('index.php?option=com_cmgroupbuying&view=order&id='.$orderId);
        $result = array(
            'validation' => false,
        );

        if(!empty($orderId) && !empty($au) && !empty($sessionData) && $sessionData['order_id'] == $orderId)
        {
            $bankData = array();
            foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
            {
                $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
            }

            $data = array (
                'pin' => $sessionData['pin'],
                'price' => $sessionData['price'],
                'order_id' => $sessionData['order_id'],
                'au' => $au,
                'bank_return' => $bankData,
            );

            list($status,$msg,$resultData) = SNApi::verify($data,'cmgroupbuying');

            if($status == true)
            {
                $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

                $result['validation'] = true;
                $result['payment_id'] = $this->paymentId;
                $result['transaction_info'] = array(
                    'Ref Number' => $bankAu,
                );
                $result['order_id'] = $orderId;

                // update status from this file [components/com_cmgroupbuying/controllers/order.php]
                $obj = new CMGroupBuyingControllerOrder;
                $obj->update($result);

                // empty cart from this file [components/com_cmgroupbuying/controllers/cart.php]
                $session = JFactory::getSession();
                $session->clear('cart', 'CMGroupBuying');

                $successMsg = '<h5>'.JText::_('SN_PAID_TRANSACTION').'</h5>';
                $successMsg = str_replace('{REF}',$bankAu,$successMsg);
                $app->redirect($url,$successMsg,'message');
                return;
            }
        }

        $errorMsg = '<h5>'.JText::_('SN_UNPAID_TRANSACTION').'</h5>';
        $app->redirect($url,$errorMsg,'error');
    }
}